<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<LINK REL="SHORTCUT ICON" HREF="<?php echo base_url(); ?>images/malinilogo.png">
<title>Shree Malani Foams </title>
<?php
//echo ($_SERVER['HTTP_USER_AGENT']);
include "dbconfig.php";
    if ( strpos($_SERVER['HTTP_USER_AGENT'], 'Gecko') && strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') || strpos($_SERVER['HTTP_USER_AGENT'], 'Gecko') && strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') )
   {
  
    ?>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/stylechrome.css" type="text/css" />
<?php
}

 else if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') || strpos($_SERVER['HTTP_USER_AGENT'], 'Presto') )
{
?>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/styleall.css" type="text/css" />
<?php
}
else
{
?>
<link rel='stylesheet' href='<?php echo base_url(); ?>css/styleall.css' type='text/css' />
<?php
}
?>



<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.simplemodal.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/init.js"></script>

</head>

<body>

<div style="overflow:auto;width:780px;height:430px;">
<div class=editpane align="justify" >


<fieldset style="border:1px solid #073c68;width:770px;"><legend><b>Order&nbsp;Details</b></legend>
<table  cellpadding="3" cellspacing="2" height="97%" width=100% border="0">






<?php 
$values=explode(":",$vars);

$res_orders=mysql_query("select *from tbl_orders where density='".$values[0]."' and variety='".$values[1]."' and remainingbundles!=0");

echo "<tr><th>Product Variety</th><th>DO Num</th><th>Party Name</th><th>Product</th><th>Order Date</th><th>Size</th><th>Bundles</th><th>Delivery Time</th></tr>";
while($row_order=mysql_fetch_array($res_orders))
{

$res=mysql_query("select *from tbl_order_master where donum='".$row_order['donum']."'");
$row=mysql_fetch_array($res);
echo "<tr><td >".$values[0]." ".$values[1]."

</td>



<td>".$row_order['donum']."</td><td>".$row['orderby']."</td>


<td>".$row_order['itemname']."</td>
<td>".$row['orderdate']."</td>

<td>".$row_order['height']."*".$row_order['width']."*".$row_order['thickness']."</td>
<td >".$row_order['remainingbundles']."</td>
<td >".$row['priority']."</td>


</tr>";

}


?>





</table>
</fieldset>







</div></div><!--main div closed-->



</body>
</html>
